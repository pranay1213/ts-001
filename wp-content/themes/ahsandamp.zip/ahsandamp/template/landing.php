<?php
 /* Template Name: ashandamp */ 

?>

<div class="hero-sec-bg">
        <section class="hero-section">
            <div class="hero-bg-block">
                <nav class="navbar fixed-top navbar-expand-lg navbar-dark p-md-3">
                    <div class="container">
                        <!-- <a class="navbar-brand" href="#">Web Zone</a> -->
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarNav">
                            <div class="mx-auto"></div>
                            <ul class="navbar-nav">
                                <!-- <li class="nav-item">
                    <a class="nav-link text-white" href="#">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white" href="#">About</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white" href="#">Blog</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white" href="#">Pricing</a>
                  </li> -->
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="#">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="banner-image w-100 vh-100 d-flex justify-content-center align-items-center">
                    <div class=" banner-title heacontent text-center">
                        <!-- <h1 class="text-white">
                <pre><span class="orangr-title">Strength</span>
                <span class="white-title"> numbers</span><span class="orangr-title">.</span></pre></h1> -->
                        <p>Welcome to Automated Handling Solutions & Advanced Material Processing</p>
                    </div>
                </div>
            </div>
        </section>

        



        <section class="left-text-right-logo-section">
            <div class="left-text-right-logo-bg-block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="hero-left-text-block">
                                <p>Representing global specialists in material handling & processing equipment solutions
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="right-logo-block">
                                <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/AHS-Logo-2C-RGB.svg">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="right-logo-block">
                                <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/AMP.png">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <section class="logo-section">
        <!-- <div class="logo-text-before-block"> -->
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/Component-50-–-14.svg" alt="logo1">
                        </div>
                        <div class="col">
                            <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/Mask-Group-16.svg" alt="logo1">
                        </div>
                        <div class="col">
                            <div class="scroll-block">
                                <a class="mouseDown" href="#section1" title="Scroll Down"><span></span>
                                </a>
                            </div>
                        </div>
                        <div class="col">
                            <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/Component-52-–-14.svg" alt="logo1">
                        </div>
                        <div class="col">
                            <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/Component-53-–-14.svg" alt="logo1">
                        </div>
                    </div>
                </div>
                <!-- <div class="logo-text-after-block">
            </div> -->
        <!-- </div> -->
    </section>
    <div class="bg-block"></div>

    <section class="product-section">
        <div class="container-fluid p-5 text-white text-center">
            <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-8">
                    <div class="product-title-block">
                        <p>Advancing engineering capabilities</p>
                        <h3>Both AHS and AMP offer a unique combination of turnkey material handling and processing
                            solutions.</h3>
                    </div>
                </div>
                <div class="col-md-2">&nbsp;</div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="product-img-block">
                        <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/TintedDiagram.svg" alt="product">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="first-block"></div>
    <section class="engg-section">
      
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="engg-block">
                        <p> With AHS combining the material handling systems of Spiroflow and Cablevey
                            Conveyors, and AMP integrating material processing systems of Kason Corporation
                            and Marion Process Solutions, the result is two unrivalled platform companies
                            that deliver integrated core competencies and market leading product portfolios
                            to customers globally.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="engg-img-block">
                        <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/Mask-Group-15.svg" alt="engg">
                    </div>
                </div>
            </div>
        </div>
       

    </section>
    <div class="last-block"></div>

    <section class="contact-form-section">
        <div class="container-fluid p-5 text-white text-center">
            <div class="row">
                <div class="col-md-3">&nbsp;</div>
                <div class="col-md-6">
                    <div class="contact-title-block">
                        <h3>Get In Touch</h3>
                        <p>Want to learn more about our solutions? Have a general question?
                            Let’s connect! Call or email us, or simply fill out the contact form below. We look forward
                            to starting a dialogue.</p>
                    </div>
                </div>
                <div class="col-md-3">&nbsp;</div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- <div class="contact-title-block">
                        <h3>Contact Information</h3>
                    </div> -->
                    <?php echo do_shortcode( '[contact-form-7 id="14" title="contact form"]'); ?>
                </div>
            </div>
        </div>
    </section>


    <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 text-center">
                    <div class="footer-img-block">
                        <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/AHS-Logo-2C-RGB.svg">
                        <img src="https://wordpress-426808-3202639.cloudwaysapps.com/wp-content/uploads/2023/01/AMP.png">
                    </div>
                    <div class="footer-text">
                        <p>1 North Wacker Drive, Suite 1920, Chicago, Illinois 60606 </p>
                    </div>
                </div>
                <div class="col-sm-3 text-center">
                    <ul class="list">
                        <li><a href="#">Brands</a></li>
                        <li><a href="#">Spirowflow</a></li>
                        <li><a href="#">Cablevey</a></li>
                        <li><a href="#">Kason</a></li>
                        <li><a href="#">Marion</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 text-center">
                    <ul class="list">
                        <li><a href="#">Policies</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">GDPR Policy</a></li>
                        <li><a href="#">Terms &amp; Conditions</a></li>
                        <li><a href="#">Cookies Policy</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 text-center"></div>
            </div>
        </div>
    
    </section>

<?php get_header();

?>







