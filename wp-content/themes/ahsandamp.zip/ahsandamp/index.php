<?php
/**
 * Template Name: Homepage
 * Description: The template for displaying the Blog index /blog.
 *
 */

get_header();

$page_id = get_option( 'page_for_posts' );
?>
<h1>Home Page</h1>
<?php
get_footer();